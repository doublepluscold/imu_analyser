// Simplest wireless UART bridge. tx: GPIO20 (UART RX) -> ESP-NOW broadcast. rx: ESP-NOW -> USB serial.
#include <Arduino.h>
#include <WiFi.h>
#include <esp_idf_version.h>
#include <esp_now.h>
#include <esp_wifi.h>

#define RX_PIN 20
#define BAUD 115200
#define CHANNEL 1

static const uint8_t BCAST[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

#if ROLE_TX

void setup() {
    Serial.begin(115200);
    Serial1.begin(BAUD, SERIAL_8N1, RX_PIN, -1);  // RX only, never writes to the line
    WiFi.mode(WIFI_STA);
    WiFi.disconnect();
    esp_wifi_set_channel(CHANNEL, WIFI_SECOND_CHAN_NONE);
    esp_now_init();
    esp_now_peer_info_t peer = {};
    memcpy(peer.peer_addr, BCAST, 6);
    peer.channel = CHANNEL;
    esp_now_add_peer(&peer);
}

void loop() {
    static uint8_t buf[200];  // ESP-NOW payload max 250
    static size_t n = 0;
    static uint32_t last = 0, sent = 0;
    while (Serial1.available() && n < sizeof buf) buf[n++] = Serial1.read();
    // send when full or after 10 ms of silence
    if (n && (n == sizeof buf || millis() - last >= 10)) {
        esp_now_send(BCAST, buf, n);
        sent += n;
        n = 0;
    }
    if (Serial1.available()) last = millis();
    static uint32_t rep = 0;
    if (millis() - rep >= 1000) {
        rep = millis();
        Serial.printf("sent bytes=%lu\n", (unsigned long)sent);
    }
}

#else

#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(5, 0, 0)
static void onRecv(const esp_now_recv_info_t *, const uint8_t *d, int len) {
#else
static void onRecv(const uint8_t *, const uint8_t *d, int len) {
#endif
    for (int i = 0; i < len; i++) Serial.printf("%02X ", d[i]);
    Serial.println();
}

void setup() {
    Serial.begin(115200);
    WiFi.mode(WIFI_STA);
    WiFi.disconnect();
    esp_wifi_set_channel(CHANNEL, WIFI_SECOND_CHAN_NONE);
    esp_now_init();
    esp_now_register_recv_cb(onRecv);
}

void loop() { delay(1000); }

#endif
